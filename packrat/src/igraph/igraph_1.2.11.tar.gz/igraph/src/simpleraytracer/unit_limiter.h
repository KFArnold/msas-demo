#ifndef ZERO_TO_ONE_H
#define ZERO_TO_ONE_H

namespace igraph {

double unit_limiter(double vUnitDouble);

} // namespace igraph

#endif
