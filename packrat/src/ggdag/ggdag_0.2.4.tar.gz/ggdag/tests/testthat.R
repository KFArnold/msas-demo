library(testthat)
library(ggdag)

test_check("ggdag")
