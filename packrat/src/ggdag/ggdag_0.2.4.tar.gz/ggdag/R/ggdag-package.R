#' @keywords internal
#' @aliases ggdag_pkg
"_PACKAGE"

## usethis namespace: start
#' @import ggplot2
## usethis namespace: end
NULL
